import os
import time
import uuid

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import JSONResponse, Response

ALLOWED_ORIGIN = "https://dash-74cf4h.example.com"
EMAIL = os.environ.get("EMAIL", "your-email@example.com")  # set EMAIL env var on your host

app = FastAPI()


@app.middleware("http")
async def cors_and_headers(request: Request, call_next):
    start = time.perf_counter()
    origin = request.headers.get("origin")
    allowed = origin == ALLOWED_ORIGIN

    if request.method == "OPTIONS":
        response = Response(status_code=200 if allowed else 403)
        if allowed:
            response.headers["Access-Control-Allow-Methods"] = "GET, OPTIONS"
            req_headers = request.headers.get("access-control-request-headers")
            response.headers["Access-Control-Allow-Headers"] = req_headers or "*"
            response.headers["Access-Control-Max-Age"] = "600"
    else:
        response = await call_next(request)

    if allowed:
        response.headers["Access-Control-Allow-Origin"] = ALLOWED_ORIGIN
        response.headers["Access-Control-Expose-Headers"] = "X-Request-ID, X-Process-Time"
    response.headers["Vary"] = "Origin"
    response.headers["X-Request-ID"] = str(uuid.uuid4())
    response.headers["X-Process-Time"] = f"{time.perf_counter() - start:.6f}"
    return response


@app.get("/stats")
async def stats(values: str = ""):
    try:
        nums = [int(v.strip()) for v in values.split(",") if v.strip() != ""]
    except ValueError:
        raise HTTPException(status_code=400, detail="values must be comma-separated integers")
    if not nums:
        raise HTTPException(status_code=400, detail="values is required")
    return {
        "email": EMAIL,
        "count": len(nums),
        "sum": sum(nums),
        "min": min(nums),
        "max": max(nums),
        "mean": sum(nums) / len(nums),
    }


@app.get("/")
async def root():
    return JSONResponse({"status": "ok"})
